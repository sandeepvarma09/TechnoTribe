
import { Language } from '../types';

export interface DistrictOption {
  value: string; // unique key, e.g., 'adilabad'
  nameKey: string; // translation key, e.g., 'districtAdilabad'
}

// List of 33 Telangana Districts
export const TELANGANA_DISTRICTS: DistrictOption[] = [
  { value: 'adilabad', nameKey: 'districtAdilabad' },
  { value: 'bhadradri_kothagudem', nameKey: 'districtBhadradriKothagudem' },
  { value: 'hyderabad', nameKey: 'districtHyderabad' },
  { value: 'jagtial', nameKey: 'districtJagtial' },
  { value: 'jangaon', nameKey: 'districtJangaon' },
  { value: 'jayashankar_bhupalapally', nameKey: 'districtJayashankarBhupalapally' },
  { value: 'jogulamba_gadwal', nameKey: 'districtJogulambaGadwal' },
  { value: 'kamareddy', nameKey: 'districtKamareddy' },
  { value: 'karimnagar', nameKey: 'districtKarimnagar' },
  { value: 'khammam', nameKey: 'districtKhammam' },
  { value: 'komaram_bheem_asifabad', nameKey: 'districtKomaramBheemAsifabad' },
  { value: 'mahabubabad', nameKey: 'districtMahabubabad' },
  { value: 'mahabubnagar', nameKey: 'districtMahabubnagar' },
  { value: 'mancherial', nameKey: 'districtMancherial' },
  { value: 'medak', nameKey: 'districtMedak' },
  { value: 'medchal_malkajgiri', nameKey: 'districtMedchalMalkajgiri' },
  { value: 'mulugu', nameKey: 'districtMulugu' },
  { value: 'nagarkurnool', nameKey: 'districtNagarkurnool' },
  { value: 'nalgonda', nameKey: 'districtNalgonda' },
  { value: 'narayanpet', nameKey: 'districtNarayanpet' },
  { value: 'nirmal', nameKey: 'districtNirmal' },
  { value: 'nizamabad', nameKey: 'districtNizamabad' },
  { value: 'peddapalli', nameKey: 'districtPeddapalli' },
  { value: 'rajanna_sircilla', nameKey: 'districtRajannaSircilla' },
  { value: 'ranga_reddy', nameKey: 'districtRangaReddy' },
  { value: 'sangareddy', nameKey: 'districtSangareddy' },
  { value: 'siddipet', nameKey: 'districtSiddipet' },
  { value: 'suryapet', nameKey: 'districtSuryapet' },
  { value: 'tandur', nameKey: 'districtTandur' },
  { value: 'vikarabad', nameKey: 'districtVikarabad' },
  { value: 'wanaparthy', nameKey: 'districtWanaparthy' },
  { value: 'warangal_rural', nameKey: 'districtWarangalRural' }, // Or just Warangal if preferred
  { value: 'warangal_urban', nameKey: 'districtWarangalUrban' }, // Or Hanumakonda
  { value: 'yadadri_bhuvanagiri', nameKey: 'districtYadadriBhuvanagiri' },
];

export const getDistrictDisplayName = (districtValue: string | undefined, t: (key: string) => string, currentLanguage: Language): string => {
  if (!districtValue) return t('notSet');
  const district = TELANGANA_DISTRICTS.find(d => d.value === districtValue);
  return district ? t(district.nameKey) : districtValue; // Fallback to value if not found (shouldn't happen ideally)
};
