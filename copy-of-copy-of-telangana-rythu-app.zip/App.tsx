

import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import Layout from './components/Layout';
import HomePage from './pages/HomePage';
import MandiRatesPage from './pages/MandiRatesPage';
import CropGuidePage from './pages/CropGuidePage';
import ChatbotPage from './pages/ChatbotPage';
import CalculatorPage from './pages/CalculatorPage';
import ReportsPage from './pages/ReportsPage';
import LoginPage from './src/pages/LoginPage';
import SignupPage from './src/pages/SignupPage';
import SignupRoleSelectionPage from './src/pages/SignupRoleSelectionPage'; 
import SplashScreenAnimated from './src/components/SplashScreenAnimated'; 
import ProfilePage from './src/pages/ProfilePage';
import EditProfilePage from './src/pages/EditProfilePage'; // Added EditProfilePage import
import { useLanguage } from './hooks/useLanguage';
import { useBackground } from './src/contexts/BackgroundContext'; 
import { REPORTS_PAGE_PATH } from './constants';
import { Language } from './types';
import { userDataService } from './services/userDataService';


const App: React.FC = () => {
  const { currentLanguage, setLanguage } = useLanguage(); 
  const { isHighContrastMode, setHighContrastMode } = useBackground(); 
  const [showSplashScreen, setShowSplashScreen] = useState(true);
  const [isLoggedIn, setIsLoggedIn] = useState(!!userDataService.getCurrentUsername()); 

  const getFontClass = () => {
    switch (currentLanguage) {
      case Language.Telugu:
        return 'telugu-font';
      case Language.Hindi:
        return 'hindi-font';
      case Language.English:
      default:
        return 'english-font';
    }
  };

  const handleSplashSequenceComplete = () => {
    setShowSplashScreen(false); 
  };

  const handleLoginSuccess = () => {
    setIsLoggedIn(true);
    const username = userDataService.getCurrentUsername();
    if (username) {
      userDataService._initializeUserData(username); 
      const prefs = userDataService.getUserPreferences(username);
      if (prefs.language) setLanguage(prefs.language);
      if (typeof prefs.highContrastMode === 'boolean') setHighContrastMode(prefs.highContrastMode);
    }
  };

  const handleLogout = () => {
    userDataService.setCurrentUsername(null);
    setIsLoggedIn(false);
  };

  useEffect(() => {
    const bodyClasses = ['bg-page-default', getFontClass()]; 
    if (isHighContrastMode) {
      bodyClasses.push('high-contrast-mode');
    }
    document.body.className = bodyClasses.join(' ');
    
    if (showSplashScreen) {
      document.documentElement.style.overflow = 'hidden';
      document.body.style.overflow = 'hidden';
    } else {
      document.documentElement.style.overflowY = 'auto';
      document.documentElement.style.overflowX = 'hidden';
      document.body.style.overflowY = 'auto';
      document.body.style.overflowX = 'hidden';
    }
    return () => { 
        document.documentElement.style.overflowY = '';
        document.documentElement.style.overflowX = '';
        document.body.style.overflowY = '';
        document.body.style.overflowX = '';
    };
  }, [currentLanguage, showSplashScreen, isHighContrastMode]);

   useEffect(() => {
    const username = userDataService.getCurrentUsername();
    if (username && isLoggedIn) {
      userDataService.saveUserPreferences(username, { 
        language: currentLanguage, 
        highContrastMode: isHighContrastMode 
      });
    }
  }, [currentLanguage, isHighContrastMode, isLoggedIn]);


  return (
    <div className={`h-full ${getFontClass()}`}>
      <div 
        id="appRouterContainer" 
        className="h-full relative z-10" 
        style={{ opacity: showSplashScreen ? 0 : 1, display: showSplashScreen ? 'none' : 'block' }} 
      >
        <HashRouter>
          {!isLoggedIn ? (
            <Routes>
              <Route path="/login" element={<LoginPage onLoginSuccess={handleLoginSuccess} />} />
              <Route path="/signup-role" element={<SignupRoleSelectionPage />} />
              <Route path="/signup" element={<SignupPage />} /> 
              <Route path="*" element={<Navigate to="/login" replace />} />
            </Routes>
          ) : (
            <Layout>
              <Routes>
                <Route path="/" element={<Navigate to="/home" replace />} />
                <Route path="/home" element={<HomePage />} />
                <Route path="/rates" element={<MandiRatesPage />} />
                <Route path="/guide" element={<CropGuidePage />} />
                <Route path="/chatbot" element={<ChatbotPage />} />
                <Route path="/calculator" element={<CalculatorPage />} />
                <Route path={REPORTS_PAGE_PATH} element={<ReportsPage />} />
                <Route path="/profile" element={<ProfilePage onLogout={handleLogout} />} />
                <Route path="/edit-profile" element={<EditProfilePage />} /> {/* Added EditProfilePage route */}
                {/* Redirect logged-in users away from auth pages */}
                <Route path="/login" element={<Navigate to="/home" replace />} />
                <Route path="/signup-role" element={<Navigate to="/home" replace />} />
                <Route path="/signup" element={<Navigate to="/home" replace />} />
              </Routes>
            </Layout>
          )}
        </HashRouter>
      </div>

      {showSplashScreen && (
        <SplashScreenAnimated 
          onAnimationComplete={handleSplashSequenceComplete} 
          loginContainerSelector="#appRouterContainer"
        />
      )}
    </div>
  );
};

export default App;
