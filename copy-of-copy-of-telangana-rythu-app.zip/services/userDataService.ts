import { UserData, UserPreferences } from '../types';

const USER_DATA_PREFIX = 'telanganaFarmerApp_userData_';
const CURRENT_USER_KEY = 'telanganaFarmerApp_currentUser';

export const userDataService = {
  getCurrentUsername: (): string | null => {
    return localStorage.getItem(CURRENT_USER_KEY);
  },

  setCurrentUsername: (username: string | null): void => {
    if (username) {
      localStorage.setItem(CURRENT_USER_KEY, username);
      // Ensure user data is initialized when a user is set (e.g., after login)
      userDataService._initializeUserData(username);
    } else {
      localStorage.removeItem(CURRENT_USER_KEY);
    }
  },

  getUserData: (username: string): UserData | null => {
    const data = localStorage.getItem(USER_DATA_PREFIX + username);
    if (data) {
      try {
        return JSON.parse(data) as UserData;
      } catch (error) {
        console.error("Error parsing user data for", username, error);
        return null;
      }
    }
    return null;
  },

  saveUserData: (username: string, data: UserData): void => {
    try {
      localStorage.setItem(USER_DATA_PREFIX + username, JSON.stringify(data));
    } catch (error) {
      console.error("Error saving user data for", username, error);
    }
  },

  // Initialize user data if it doesn't exist
  _initializeUserData: (username: string): UserData => {
    const existingData = userDataService.getUserData(username);
    if (existingData) {
      // Ensure existing data has new fields, providing defaults if not
      const updatedData: UserData = {
        displayName: username, 
        phoneNumber: '', 
        district: '', 
        profilePictureUrl: '', 
        myCropIds: [],
        preferences: {},
        ...existingData, 
      };
      // If any of the new fields were missing, save the updated structure
      if (
        !existingData.hasOwnProperty('displayName') ||
        !existingData.hasOwnProperty('phoneNumber') ||
        !existingData.hasOwnProperty('district') ||
        !existingData.hasOwnProperty('profilePictureUrl')
      ) {
        userDataService.saveUserData(username, updatedData);
      }
      return updatedData;

    }
    const newUser: UserData = {
      username,
      displayName: username, 
      phoneNumber: '', 
      district: '', 
      profilePictureUrl: '', 
      myCropIds: [],
      preferences: {},
    };
    userDataService.saveUserData(username, newUser);
    return newUser;
  },

  addCropToUser: (username: string, cropId: string): void => {
    const userData = userDataService._initializeUserData(username);
    if (!userData.myCropIds.includes(cropId)) {
      userData.myCropIds.push(cropId);
      userDataService.saveUserData(username, userData);
    }
  },

  removeCropFromUser: (username: string, cropId: string): void => {
    const userData = userDataService._initializeUserData(username);
    userData.myCropIds = userData.myCropIds.filter(id => id !== cropId);
    userDataService.saveUserData(username, userData);
  },

  isUserCrop: (username: string, cropId: string): boolean => {
    const userData = userDataService.getUserData(username);
    return userData ? userData.myCropIds.includes(cropId) : false;
  },
  
  getUserPreferences: (username: string): UserPreferences => {
    const userData = userDataService._initializeUserData(username);
    return userData.preferences;
  },

  saveUserPreferences: (username: string, preferences: Partial<UserPreferences>): void => {
    const userData = userDataService._initializeUserData(username);
    userData.preferences = { ...userData.preferences, ...preferences };
    userDataService.saveUserData(username, userData);
  },

  getProfilePictureUrl: (username: string): string | null => {
    const userData = userDataService.getUserData(username);
    return userData?.profilePictureUrl || null;
  },

  updateProfilePicture: (username: string, base64Url: string | null): void => {
    const userData = userDataService._initializeUserData(username);
    userData.profilePictureUrl = base64Url || ''; // Store empty string if null
    userDataService.saveUserData(username, userData);
  }
};