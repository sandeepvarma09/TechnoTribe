import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../../hooks/useLanguage';
import { UserData } from '../../types';
import { userDataService } from '../../services/userDataService';
import { TELANGANA_DISTRICTS, DistrictOption } from '../../data/telanganaDistricts';
import LoadingSpinner from '../../components/LoadingSpinner';
import { UserCircleIcon, PhoneIcon, MapPinIcon as LocationMarkerIcon, ArrowPathIcon, CameraIcon, TrashIcon } from '../../components/icons/CoreIcons';

const EditProfilePage: React.FC = () => {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [currentUsername, setCurrentUsername] = useState<string | null>(null);
  const [displayName, setDisplayName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [district, setDistrict] = useState('');
  const [profilePicturePreview, setProfilePicturePreview] = useState<string | null>(null);
  const [newProfilePictureFile, setNewProfilePictureFile] = useState<File | null>(null);
  
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  useEffect(() => {
    const username = userDataService.getCurrentUsername();
    if (username) {
      setCurrentUsername(username);
      const data = userDataService.getUserData(username);
      if (data) {
        setDisplayName(data.displayName || '');
        setPhoneNumber(data.phoneNumber || '');
        setDistrict(data.district || '');
        setProfilePicturePreview(data.profilePictureUrl || null);
      } else {
        navigate('/profile'); 
      }
    } else {
      navigate('/login');
    }
    setLoading(false);
  }, [navigate]);

  const validatePhoneNumber = (number: string): boolean => {
    if (!number) return true; 
    const phoneRegex = /^\d{10}$/; 
    return phoneRegex.test(number);
  };

  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setNewProfilePictureFile(file); // Store the file itself
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfilePicturePreview(reader.result as string); // Set preview
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemovePicture = () => {
    setNewProfilePictureFile(null);
    setProfilePicturePreview(null);
    if (fileInputRef.current) {
        fileInputRef.current.value = "";
    }
  };

  const handleSaveChanges = async () => {
    if (!currentUsername) return;
    setError(null);
    setSuccessMessage(null);

    if (!displayName.trim()) {
      setError(t('pleaseEnterDisplayName', 'Please enter a display name.'));
      return;
    }
    if (phoneNumber && !validatePhoneNumber(phoneNumber)) {
      setError(t('pleaseEnterValidPhoneNumber', 'Please enter a valid 10-digit phone number.'));
      return;
    }

    setSaving(true);
    let newProfilePictureBase64: string | null = profilePicturePreview; // Keep current if no new file

    if (newProfilePictureFile) { // If a new file was selected
      try {
        newProfilePictureBase64 = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result as string);
          reader.onerror = reject;
          reader.readAsDataURL(newProfilePictureFile);
        });
      } catch (imgError) {
        console.error("Error reading image file:", imgError);
        setError(t('errorUploadingProfilePicture', 'Error processing profile picture.'));
        setSaving(false);
        return;
      }
    } else if (profilePicturePreview === null) { // If explicitly removed
        newProfilePictureBase64 = null;
    }


    const currentUserData = userDataService.getUserData(currentUsername);
    if (currentUserData) {
      const updatedUserData: UserData = {
        ...currentUserData,
        displayName: displayName.trim(),
        phoneNumber: phoneNumber.trim(),
        district: district,
        profilePictureUrl: newProfilePictureBase64 || '', // Store empty string if null
      };
      userDataService.saveUserData(currentUsername, updatedUserData);
      setSuccessMessage(t('profileUpdatedSuccessfully', 'Profile updated successfully!'));
      setTimeout(() => {
        setSaving(false);
        navigate('/profile');
      }, 1500);
    } else {
      setError(t('errorUpdatingProfile', 'Error updating profile.'));
      setSaving(false);
    }
  };

  const handleCancel = () => {
    navigate('/profile');
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-full">
        <LoadingSpinner text={t('loading')} />
      </div>
    );
  }

  return (
    <div className="container mx-auto max-w-lg p-4 sm:p-6">
      <div className="bg-white shadow-xl rounded-xl p-6 sm:p-8">
        <h1 className="text-2xl sm:text-3xl font-bold text-gray-800 text-center mb-6">
          {t('editProfile', 'Edit Profile')}
        </h1>

        {error && <p className="mb-4 text-center text-sm text-red-600 bg-red-100 p-3 rounded-md">{error}</p>}
        {successMessage && <p className="mb-4 text-center text-sm text-green-600 bg-green-100 p-3 rounded-md">{successMessage}</p>}

        <form onSubmit={(e) => { e.preventDefault(); handleSaveChanges(); }} className="space-y-6">
          
          {/* Profile Picture Section */}
          <div className="flex flex-col items-center space-y-3">
            <div className="relative">
              {profilePicturePreview ? (
                <img 
                  src={profilePicturePreview} 
                  alt={t('profilePicturePreview', 'Profile Picture Preview')} 
                  className="w-32 h-32 rounded-full object-cover border-2 border-gray-300"
                />
              ) : (
                <UserCircleIcon className="w-32 h-32 text-gray-400" />
              )}
               <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="absolute -bottom-1 -right-1 bg-primary text-white p-2 rounded-full hover:bg-primary-dark shadow-md"
                aria-label={t('uploadProfilePicture', 'Upload Profile Picture')}
                title={t('uploadProfilePicture', 'Upload Profile Picture')}
              >
                <CameraIcon className="w-5 h-5" />
              </button>
            </div>
            <input
              type="file"
              accept="image/*"
              onChange={handleImageChange}
              className="hidden"
              ref={fileInputRef}
              id="profilePictureUpload"
            />
            {profilePicturePreview && (
              <button
                type="button"
                onClick={handleRemovePicture}
                className="text-xs text-red-500 hover:text-red-700 flex items-center"
              >
                <TrashIcon className="w-3 h-3 mr-1" /> {t('removeProfilePicture', 'Remove Picture')}
              </button>
            )}
          </div>


          <div>
            <label htmlFor="displayName" className="block text-sm font-medium text-gray-700 mb-1">
              {t('displayName', 'Display Name')} <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <UserCircleIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                id="displayName"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full p-3 pl-10 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-primary focus:border-transparent"
                required
              />
            </div>
          </div>

          <div>
            <label htmlFor="phoneNumber" className="block text-sm font-medium text-gray-700 mb-1">
              {t('phoneNumber', 'Phone Number')}
            </label>
             <div className="relative">
              <PhoneIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="tel"
                id="phoneNumber"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="e.g. 9876543210"
                className="w-full p-3 pl-10 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-primary focus:border-transparent"
              />
            </div>
          </div>

          <div>
            <label htmlFor="district" className="block text-sm font-medium text-gray-700 mb-1">
              {t('district', 'District')}
            </label>
            <div className="relative">
              <LocationMarkerIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <select
                id="district"
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                className="w-full p-3 pl-10 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-primary focus:border-transparent appearance-none"
              >
                <option value="">{t('selectDistrict', 'Select District')}</option>
                {TELANGANA_DISTRICTS.map((d: DistrictOption) => (
                  <option key={d.value} value={d.value}>
                    {t(d.nameKey)}
                  </option>
                ))}
              </select>
               <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-gray-700">
                <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M5.516 7.548c.436-.446 1.043-.48 1.576 0L10 10.405l2.908-2.857c.533-.48 1.141-.446 1.574 0 .436.445.408 1.197 0 1.615-.406.418-4.695 4.502-4.695 4.502a1.095 1.095 0 01-1.576 0S5.922 9.581 5.516 9.163c-.409-.418-.436-1.17 0-1.615z"/></svg>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4 pt-4">
            <button
              type="button"
              onClick={handleCancel}
              disabled={saving}
              className="w-full sm:w-1/2 bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold py-3 px-4 rounded-lg shadow-md focus:outline-none focus:ring-2 focus:ring-gray-400 transition-colors"
            >
              {t('cancel', 'Cancel')}
            </button>
            <button
              type="submit"
              disabled={saving}
              className="w-full sm:w-1/2 bg-primary hover:bg-primary-dark text-white font-semibold py-3 px-4 rounded-lg shadow-md focus:outline-none focus:ring-2 focus:ring-primary-light transition-colors flex items-center justify-center disabled:opacity-70"
            >
              {saving && <ArrowPathIcon className="animate-spin h-5 w-5 mr-2" />}
              {saving ? t('loading') : t('saveChanges', 'Save Changes')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditProfilePage;