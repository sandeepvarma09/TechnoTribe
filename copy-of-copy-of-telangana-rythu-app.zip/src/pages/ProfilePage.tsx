import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../../hooks/useLanguage';
import { UserData, Language } from '../../types';
import { userDataService } from '../../services/userDataService';
import { ArrowLeftOnRectangleIcon, UserCircleIcon, PhoneIcon, MapPinIcon as LocationMarkerIcon, PencilIcon } from '../../components/icons/CoreIcons';
import LoadingSpinner from '../../components/LoadingSpinner';
import { getDistrictDisplayName } from '../../data/telanganaDistricts'; 

interface ProfilePageProps {
  onLogout: () => void;
}

const ProfilePage: React.FC<ProfilePageProps> = ({ onLogout }) => {
  const { t, currentLanguage } = useLanguage(); 
  const navigate = useNavigate();
  const [userData, setUserData] = useState<UserData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const currentUsername = userDataService.getCurrentUsername();
    if (currentUsername) {
      const data = userDataService.getUserData(currentUsername);
      setUserData(data || userDataService._initializeUserData(currentUsername));
    } else {
      navigate('/login');
    }
    setLoading(false);
  }, [navigate]);

  const handleLogoutClick = () => {
    onLogout();
    navigate('/login');
  };
  
  const handleEditProfile = () => {
    navigate('/edit-profile');
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-full">
        <LoadingSpinner text={t('loading')} />
      </div>
    );
  }

  if (!userData) {
    return (
      <div className="text-center p-8">
        <p>{t('error', 'Error loading user data.')}</p>
        <button onClick={() => navigate('/login')} className="mt-4 text-primary hover:underline">
          {t('loginButton', 'Go to Login')}
        </button>
      </div>
    );
  }

  const { displayName, phoneNumber, district, profilePictureUrl } = userData;
  const displayDistrictName = getDistrictDisplayName(district, t, currentLanguage as Language);

  return (
    <div className="container mx-auto max-w-lg p-4 sm:p-6">
      <div className="bg-white shadow-xl rounded-xl p-6 sm:p-8">
        <div className="flex flex-col items-center mb-6">
          {profilePictureUrl ? (
            <img 
              src={profilePictureUrl} 
              alt={t('profile', 'Profile')} 
              className="w-24 h-24 sm:w-32 sm:h-32 rounded-full object-cover mb-3 border-2 border-primary"
            />
          ) : (
            <UserCircleIcon className="w-24 h-24 sm:w-32 sm:h-32 text-primary mb-3" />
          )}
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">{displayName}</h1>
          <button
            onClick={handleEditProfile}
            className="mt-2 text-sm text-accent hover:text-accent-dark flex items-center"
            aria-label={t('editProfile', 'Edit Profile')}
          >
            <PencilIcon className="w-3 h-3 mr-1" />
            {t('editProfile', 'Edit Profile')}
          </button>
        </div>

        <div className="space-y-4">
          <div className="flex items-center p-3 bg-gray-50 rounded-lg">
            <UserCircleIcon className="w-6 h-6 text-gray-500 mr-3" />
            <div>
              <p className="text-xs text-gray-500">{t('displayName', 'Display Name')}</p>
              <p className="text-gray-800 font-medium">{displayName || t('notSet', 'Not set')}</p>
            </div>
          </div>
          <div className="flex items-center p-3 bg-gray-50 rounded-lg">
            <PhoneIcon className="w-6 h-6 text-gray-500 mr-3" />
            <div>
              <p className="text-xs text-gray-500">{t('phoneNumber', 'Phone Number')}</p>
              <p className="text-gray-800 font-medium">{phoneNumber || t('notSet', 'Not set')}</p>
            </div>
          </div>
          <div className="flex items-center p-3 bg-gray-50 rounded-lg">
            <LocationMarkerIcon className="w-6 h-6 text-gray-500 mr-3" />
            <div>
              <p className="text-xs text-gray-500">{t('district', 'District')}</p>
              <p className="text-gray-800 font-medium">{displayDistrictName}</p>
            </div>
          </div>
        </div>

        <div className="mt-8">
          <button
            onClick={handleLogoutClick}
            className="w-full flex items-center justify-center bg-red-500 hover:bg-red-600 text-white font-semibold py-3 px-4 rounded-lg shadow-md focus:outline-none focus:ring-2 focus:ring-red-400 focus:ring-opacity-75 transition-colors"
            aria-label={t('logout', 'Logout')}
          >
            <ArrowLeftOnRectangleIcon className="w-5 h-5 mr-2" />
            {t('logout', 'Logout')}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;